/* tslint:disable */
require("./VerticalSideBar.module.css");
const styles = {
  verticalSideBar: 'verticalSideBar_ff09512d',
  teams: 'teams_ff09512d',
  welcome: 'welcome_ff09512d',
  welcomeImage: 'welcomeImage_ff09512d',
  links: 'links_ff09512d'
};

export default styles;
/* tslint:enable */