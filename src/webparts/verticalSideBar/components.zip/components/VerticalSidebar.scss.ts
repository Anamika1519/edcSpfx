/* tslint:disable */
require("./VerticalSidebar.css");
const styles = {

};

export default styles;
/* tslint:enable */